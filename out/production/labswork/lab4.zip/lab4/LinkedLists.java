package lab4;

import ca.camosun.ics124.lab4.List;

import java.util.NoSuchElementException;

public class LinkedLists<E> implements List<E> {
    int size = 0;
    List list;
    //    E item;
    Node first;
    Node last;

    public LinkedLists() {
    }

    //    public LinkedLists(Node first, Node last) {
//        this.first = first;
//        this.last = last;
//        this.first.next = this.last;
//        this.last.prev = this.first;
//
//    }

    /**
     * Returns the number of elements in the list.
     *
     * @return total number of elements stored in this collection.
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * Remove all elements from this collection.
     * set both head and tail to null ,so can not  access to this abstract list
     */
    @Override
    public void clear() {
        this.first = null;
        this.last = null;
    }

    /**
     * Get the element stored at the beginning of the list. This element is not removed from the collection.
     *
     * @return the first(head) element stored in this collection.
     * @throws NoSuchElementException - if the list is empty.
     */
    @Override
    public E first() throws NoSuchElementException {
        final Node<E> f = first;
        if (f == null) {
            throw new NoSuchElementException();
        }
        return f.item;
    }

    /**
     * Get the element stored at the beginning of the list. This element is not removed from the collection.     *
     *
     * @return the last (tail) element stored in this collection.
     * @throws NoSuchElementException - if the list is empty.
     */
    @Override
    public E last() throws NoSuchElementException {
        final Node<E> l = last;
        if (l == null) {
            throw new NoSuchElementException();
        }
        return l.item;
    }

    /**
     * Get the element stored at the given position in the list.     *
     *
     * @param -position of the element to retrieve ,if i <0,count from tail
     * @return the element at the given position
     * @throws IndexOutOfBoundsException -if index ∉ [-size(), size())
     */
    @Override
    public E get(int i) throws IndexOutOfBoundsException {
        int index = 0;
        if (Math.abs(i) >= this.size()) {
            throw new IndexOutOfBoundsException("index ∉ [-size(), size())");
        } else if (i >= 0) {
            index = i;
        } else if (i < 0) {
            index = this.size() + i;
        }
        for (int count = 0; count < index; count++) {
            this.first = this.first.next;
        }
        return (E) this.first;
    }

    @Override
    public void add(E e) {
        if (e == null) {
            return;
        }
        final Node<E> f = first;
        final Node<E> newNode = new Node<>(null, e, f);
        first = newNode;
        if (f == null) {
            last = newNode;
        } else {
            f.prev = newNode;
        }
        size++;
    }

    /**
     * Inserts an element at the given position.
     *
     * @param e - element to be added
     * @param i - position at which the new element will be inserted
     * @throws IndexOutOfBoundsException- if index ∉ [-size(), size()]
     */
    @Override
    public void add(E e, int i) throws IndexOutOfBoundsException {
        int index = 0;
        if (Math.abs(i) > this.size()) {
            throw new IndexOutOfBoundsException("index ∉ [-size(), size()]");
        } else if (i >= 0) {
            index = i;
        } else if (i < 0) {
            index = this.size() + i;
        }
        Node insert = (Node) get(i);
        //todo get method may destroy the original list ,need to figure out
    }

    /**
     * Removes the element at the given position from the list and returns it.
     *size -- ,once method executed
     * @param i- position of the element to be removed
     * @return the element that was removed
     * @throws IndexOutOfBoundsException- if index ∉ [-size(), size())
     */
    @Override
    public E remove(int i) throws IndexOutOfBoundsException {
        int index = 0;
        Node key = new Node(null, null, null);
        if (Math.abs(i) > this.size()) {
            throw new IndexOutOfBoundsException("index ∉ [-size(), size()]");
        } else if (i > 0) {
            index = i;
            key = this.first;
            for (int k = 0; k < index; k++) {
                key = key.next;
            }
        } else if (i < 0) {
            index = this.size() + i;
        } else if (i == 0) {
            key = this.first;
        }
        key.prev.next = key.next;
        key.next.prev = key.prev;
        size--;
        return (E) key;
    }

    /**
     *
     * @param e the element to search for
     * @return position index
     * @throws NoSuchElementException if no return in if and else block
     */
    @Override
    public int indexOf(E e) throws NoSuchElementException {
        int counter = 0;
        if (e == null) {
            for (Node x = first; x != null; x = x.next) {
                if (x.item == null) {
                    return counter;
                }
                counter++;
            }
        } else {
            for (Node x = first; x != null; x = x.next) {
                if (x.item.equals(e)) {
                    return counter;
                }
                counter++;
            }
        }
        throw new NoSuchElementException();
    }

    /**
     * Reverses the order of all elements in this list.
     */
    @Override
    public void reverse() {
        Node temp = null;
        Node current = first;
        while (current != null) {
            temp = current.prev;
            current.prev = current.next;
            current.next = temp;
            current = current.prev;
        }
        if (temp != null) {
            first = temp.prev;
        }
    }

    /**
     * Splits the list in two at the given position.
     * The element at that position and all following elements will be removed from this list and returned as part of a new list.
     *
     * @param i- position of the first element to be removed
     * @return a new list containing all elements that were removed
     * @throws IndexOutOfBoundsException - if index ∉ [-size(), size())
     */
    @Override
    public List<E> cut(int i) throws IndexOutOfBoundsException {
        this.list = new LinkedLists();
        try {
            Node cutter = (Node) get(i);
            list = new LinkedLists();
        } catch (IndexOutOfBoundsException index) {
            throw new IndexOutOfBoundsException("index ∉ [-size(), size())");
        }
        return this.list;
    }
    //todo not finished ,get rid of list

}

class Node<E> {
    E item;
    Node<E> next;
    Node<E> prev;

    public Node(Node<E> prev, E element, Node<E> next) {
        this.item = element;
        this.next = next;
        this.prev = prev;
    }

    @Override
    public String toString() {
        return "Node{" +
                "item=" + item +
                '}';
    }
}