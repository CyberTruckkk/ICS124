package lab4;

public class Test {
//    public static void main(String[] args) {
//        Node<Integer> nodeA = new Node(1);
//        Node<Integer> nodeB = new Node(2);
//        Node<Integer> nodeC = new Node(3);
//        nodeA.next = nodeB;
//        nodeB.prev = nodeA;
//        nodeB.next = nodeC;
//        nodeC.prev = nodeB;
//        Node first = nodeA;
//        while (true) {
//            if (first == null) {
//                break;
//            } else {
//                System.out.println(first);
//                first = first.next;
//            }
//        }
//        LinkedLists<Integer> integerLinkedLists = new LinkedLists<>(nodeA, nodeC);
//        integerLinkedLists.add(0);
//        integerLinkedLists.add(-1);
//        System.out.println(integerLinkedLists);
//    }
    }