package GuoWenlong_lab4.lab4;

import java.util.LinkedList;


public class Stand {
    public static void main(String[] args) {
        LinkedList<Integer> list = new LinkedList();
        list.add(0);
        list.add(1);
        list.add(2);
        System.out.println(list);

    }

}
